export class SupportRequest {
    public description: string;
    public status: string;
    public issueType: string;
    public customerId: number;
    public administratorId: number;
}