import { Category } from "./Category";

export class Product {
    public productId: number;
    public productName: string;
    public description: string;
    public price: number;
    public stockQnt: number;
    public category: Category;
    public imgUrl: string;
}