export class Address
{
    public addressId: number;
    public area: string;
    public pin: string;
    public street: string;
    public building: string;
    public city: string;
    public state: string;
}