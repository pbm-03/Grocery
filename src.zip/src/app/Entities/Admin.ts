export class Admin{
    public adminId: number;
    public adminName: string;
    public email: string;
    public adminContact: string;
    public password: string;
}