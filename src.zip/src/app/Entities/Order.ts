import { Address } from "./Address";
import { Customer } from "./Customer";
import { Delivery } from "./Delivery";
import { Payment } from "./Payment";
import { Product } from "./Product";

export class Order {
    public orderId: number;
    public customer: Customer;
    public listOfProducts: Product[];
    public deliveryAddress: Address;
    public orderDate: Date;
    public orderStatus: string;
    public payment: Payment;
    public delivery: Delivery;
}