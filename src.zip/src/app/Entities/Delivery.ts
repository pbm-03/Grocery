import { DeliveryPerson } from "./DeliveryPerson ";
import { Order } from "./Order";

export class Delivery{
    public deliveryId: number;
    public order: Order;
    public deliveryPerson: DeliveryPerson;
    public deliveryStatus: string;
    public deliveryOption: string;
}