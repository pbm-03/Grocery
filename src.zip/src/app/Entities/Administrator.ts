import { Support } from "./Support";

export class Administrator {
    public administratorId: number;
    public name: string;
    public email: string;
    public contact: string;
    public password: string;
    // public listOfSupport: Support[];
}