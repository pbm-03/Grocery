import { Order } from "./Order";

export class Payment {
    public paymentId: number;
    public amount: number;
    public paymentMethod: string;
    public paymentStatus: string;
    public order: Order;
}