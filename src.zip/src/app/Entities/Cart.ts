import { Customer } from "./Customer";
import { Product } from "./Product";

export class Cart {
    public cartId: number;
    public customer: Customer;
    public listOfProduct: Product[];
    public totalPrice: number;
    public quantity: number;
}