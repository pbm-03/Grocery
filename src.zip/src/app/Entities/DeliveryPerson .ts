import { Delivery } from "./Delivery";

export class DeliveryPerson {
    public deliveryPersonId: number;
    public name: string;
    public listOfDelivery: Delivery[];
}