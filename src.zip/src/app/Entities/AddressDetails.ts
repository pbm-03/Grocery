export class AddressDetails
{
    
        public customerId: number;
        public area: string;
        public building: string;
        public city: string;
        public pin: string;
        public state: string;
        public street: string
}