import { Address } from "./Address";
import { Order } from "./Order";
import { Support } from "./Support";

export class Customer {
    public customerId: number;
    public customerName: string;
    public mobileNumber: string;
    public email: string;
    public password: string;
    public address: Address[];
    public listOfOrder: Order[];
    public listOfSupport: Support[];
}