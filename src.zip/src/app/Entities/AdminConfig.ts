export class AdminConfig {
    public adminConfigId: number;
    public deliveryFee: number;
    public taxes: number;
    public paymentMethods: string;
}