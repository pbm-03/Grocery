export class URLS{
    customerURL:string='http://localhost:9091/customer';
    adminURL:string='http://localhost:9091/admin';
    productURL:string='http://localhost:9091/product';
    orderURL:string='http://localhost:9091/order';
    cartURL:string='http://localhost:9091/cart';
    adminiURL:string='http://localhost:9091/administrator';
}