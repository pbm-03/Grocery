import { Product } from "./Product";

export class Category {
    public categoryId: number;
    public categoryName: string;
    public listOfProduct: Product[];
}