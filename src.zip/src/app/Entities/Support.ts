import { Administrator } from "./Administrator";
import { Customer } from "./Customer";

export class Support {
    public supportId: number;
    public issueType: string;
    public issueDescription: string;
    public issueStatus: string;
    public createdDate: Date;
    public customer: Customer;
    public administrator: Administrator;
}