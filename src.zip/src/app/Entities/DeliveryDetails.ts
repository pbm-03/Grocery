import { Order } from "./Order";

export class DeliveryDetails {
    public order: Order;
    public deliveryOption: string;
    public deliveryPersonId: number;
    public deliveryStatus: string;
}