import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AnalyticsComponent } from './Components/Admin-Component/analytics/analytics.component';
import { DashboardComponent } from './Components/Admin-Component/dashboard/dashboard.component';
import { ProfileComponent } from './Components/Admin-Component/profile/profile.component';
import { SystemConfigComponent } from './Components/Admin-Component/system-config/system-config.component';
import { AdminiDashboardComponent } from './Components/Administrator-Component/admini-dashboard/admini-dashboard.component';
import { AdminiProfileComponent } from './Components/Administrator-Component/admini-profile/admini-profile.component';
import { AdminiSupportComponent } from './Components/Administrator-Component/admini-support/admini-support.component';
import { ProductsComponent } from './Components/Administrator-Component/products/products.component';
import { HomeComponent } from './Components/Customer-Component/home/home.component';
import { OrderComponent } from './Components/Customer-Component/order/order.component';
import { SupportComponent } from './Components/Customer-Component/support/support.component';
import { LoginComponent } from './Components/login/login.component';
import { RegisterComponent } from './Components/register/register.component';
import { AboutComponent } from './Components/about/about.component';
import { CartComponent } from './Components/Customer-Component/cart/cart.component';
import { CustomerProfileComponent } from './Components/Customer-Component/customer-profile/customer-profile.component';
import { AdminLoginComponent } from './Components/Admin-Component/admin-login/admin-login.component';
import { AdminiLoginComponent } from './Components/Administrator-Component/admini-login/admini-login.component';
import { CustomerprofileUpdateComponent } from './Components/Customer-Component/customerprofile-update/customerprofile-update.component';
import { AdminRegisterComponent } from './Components/Admin-Component/admin-register/admin-register.component';
import { AdminiRegisterComponent } from './Components/Administrator-Component/admini-register/admini-register.component';
import { AllordersComponent } from './Components/Admin-Component/allorders/allorders.component';
import { AllcustomersComponent } from './Components/Admin-Component/allcustomers/allcustomers.component';
import { UpdateProductsComponent } from './Components/Admin-Component/update-products/update-products.component';

const routes: Routes = [
  {
    path:'analytics',
    component:AnalyticsComponent
  },{
    path:'admin-dashboard',
    component:DashboardComponent
  },{
    path:'system-config',
    component:SystemConfigComponent
  },{
    path:'administrator-dashboard',
    component:AdminiDashboardComponent
  },{
    path:'admini-profile',
    component:AdminiProfileComponent
  },{
    path:'admini-support',
    component:AdminiSupportComponent
  },{
    path:'prodcuts',
    component:ProductsComponent
  },{
    path:'',
    component:HomeComponent
  },{
    path:'order',
    component:OrderComponent
  },{
    path:'support',
    component:SupportComponent
  },{
    path:'login',
    component:LoginComponent
  },{
    path:'register',
    component:RegisterComponent
  },{
    path:'about',
    component:AboutComponent
  },{
    path:'cart',
    component:CartComponent
  },{
    path:'customer-profile',
    component:CustomerProfileComponent
  },{
    path:'admin-login',
    component:AdminLoginComponent
  },{
    path:'admini-login',
    component:AdminiLoginComponent
  },{
    path:'customerprofile-update',
    component:CustomerprofileUpdateComponent
  },{
    path:'admin-register',
    component:AdminRegisterComponent
  },{
    path:'admini-register',
    component:AdminiRegisterComponent
  },{
    path:'dashboard',
    component:DashboardComponent
  },{
    path:'profile',
    component:ProfileComponent
  },{
    path:'admin-config',
    component:SystemConfigComponent
  },{
    path:'products',
    component:ProductsComponent
  },{
    path:'allorders',
    component:AllordersComponent
  },{
    path:'allcustomers',
    component:AllcustomersComponent
  },{
    path:'update-products/:productid',
    component:UpdateProductsComponent
  },{
    path:'admini-dashboard',
    component:AdminiDashboardComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
