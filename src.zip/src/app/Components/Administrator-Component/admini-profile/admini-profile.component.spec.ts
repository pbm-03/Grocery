import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminiProfileComponent } from './admini-profile.component';

describe('AdminiProfileComponent', () => {
  let component: AdminiProfileComponent;
  let fixture: ComponentFixture<AdminiProfileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminiProfileComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminiProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
