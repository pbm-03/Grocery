import { Component } from '@angular/core';

@Component({
  selector: 'app-admini-profile',
  templateUrl: './admini-profile.component.html',
  styleUrls: ['./admini-profile.component.css']
})
export class AdminiProfileComponent {

}
