import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Administrator } from 'src/app/Entities/Administrator';
import { AdminServiceService } from 'src/app/Services/admin-service.service';
import { AdminiServiceService } from 'src/app/Services/admini-service.service';
import { CustomerService } from 'src/app/Services/customer.service';

@Component({
  selector: 'app-admini-dashboard',
  templateUrl: './admini-dashboard.component.html',
  styleUrls: ['./admini-dashboard.component.css']
})
export class AdminiDashboardComponent implements OnInit {
  administratorId: number;
  name: string;
  email: string;
  contact: string;
  password: string;
  administrator: Administrator = new Administrator();  // Initialize the administrator object

  constructor(
    private adminService: AdminServiceService,
    private route: Router,
    private customerService: CustomerService,
    private service: AdminiServiceService
  ) {}

  ngOnInit(): void {
    // Get the email from the service
    this.email = this.service.getEmail();
    console.log('Admin Email:', this.email);

    // Fetch the admin data by email
    if (this.email) {
      this.service.getAdminiByEmail(this.email).subscribe(
        (adminData) => {
          this.administrator = adminData;
          console.log('Admin Data:', this.administrator);  // Check the data structure
          // Once the data is fetched, update the local variables
          this.administratorId = this.administrator.administratorId;
          this.name = this.administrator.name;
          this.contact = this.administrator.contact;
          this.password = this.administrator.password;
        },
        (error) => {
          console.error('Error fetching admin data:', error);
        }
      );
    }
  }

  handleOrders(): void {
    this.route.navigate(['/allorders']);
  }

  handleProducts(): void {
    this.route.navigate(['/products']);
  }

  handleCustomers(): void {
    this.route.navigate(['/allcustomers']);
  }

}
