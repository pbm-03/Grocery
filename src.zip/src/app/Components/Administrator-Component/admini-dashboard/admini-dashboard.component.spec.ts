import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminiDashboardComponent } from './admini-dashboard.component';

describe('AdminiDashboardComponent', () => {
  let component: AdminiDashboardComponent;
  let fixture: ComponentFixture<AdminiDashboardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminiDashboardComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminiDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
