import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Administrator } from 'src/app/Entities/Administrator';
import { AdminiServiceService } from 'src/app/Services/admini-service.service';

@Component({
  selector: 'app-admini-register',
  templateUrl: './admini-register.component.html',
  styleUrls: ['./admini-register.component.css']
})
export class AdminiRegisterComponent {
  adminis:Administrator[]=[]
 
  administrator:Administrator={administratorId:0,name:"",email:"",contact:"",password:""}
 
  constructor(private adminiService:AdminiServiceService ){}
 
  onSubmit(signupForm: NgForm): void {
    if (signupForm.valid) {
        this.adminiService.administratorRegister(this.administrator).subscribe(
            (response) => {
                console.log('Registration successful:', response);
                alert("Registration successful!");
                signupForm.resetForm();  // Optional: reset the form after submission
            },
            (error) => {
                console.error('Error registering administrator:', error);
                alert('There was an error during registration. Please try again.');
            }
        );
    } else {
        alert('Form is not valid!');
    }
}
}