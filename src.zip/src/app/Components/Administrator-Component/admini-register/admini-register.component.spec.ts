import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminiRegisterComponent } from './admini-register.component';

describe('AdminiRegisterComponent', () => {
  let component: AdminiRegisterComponent;
  let fixture: ComponentFixture<AdminiRegisterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminiRegisterComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminiRegisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
