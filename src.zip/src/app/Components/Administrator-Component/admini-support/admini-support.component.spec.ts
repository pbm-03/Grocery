import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminiSupportComponent } from './admini-support.component';

describe('AdminiSupportComponent', () => {
  let component: AdminiSupportComponent;
  let fixture: ComponentFixture<AdminiSupportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminiSupportComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminiSupportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
