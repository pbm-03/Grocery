import { Component } from '@angular/core';

@Component({
  selector: 'app-admini-support',
  templateUrl: './admini-support.component.html',
  styleUrls: ['./admini-support.component.css']
})
export class AdminiSupportComponent {

}
