import { Component } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminiServiceService } from 'src/app/Services/admini-service.service';

@Component({
  selector: 'app-admini-login',
  templateUrl: './admini-login.component.html',
  styleUrls: ['./admini-login.component.css']
})
export class AdminiLoginComponent {
  signInForm: FormGroup;
  loginError: string = ''; // Store any login error messages
  loginSuccess: boolean = false; // For showing a success message
  user: any = null; // To store user object after successful login
  errorMessage: string | null = null;
 
  constructor(
    private adminiService: AdminiServiceService,
    private fb: FormBuilder,
    private router: Router // Use Router to navigate to the dashboard
  ) {
    // Initialize the form with validators
    this.signInForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
    });
  }

  onSubmit(): void {
    if (this.signInForm.invalid) {
      return;
    }

    const email = this.signInForm.value.email;
    const password = this.signInForm.value.password;

    this.adminiService.administratorLogin(email, password).subscribe(
      (response) => {
        if (response) {
          // Save user data if needed and navigate
          this.router.navigate(['/admini-dashboard']); // Redirect to the desired page after successful login
        } else {
          // If invalid credentials, display an error message
          this.loginError = 'Invalid password or email, please try again.';
        }
      },
      (error) => {
        console.error('Login failed', error);
        this.loginError = 'There was an error processing your login. Please try again later.';
      }
    );
  }
  newregister(){
    this.router.navigate(['/admini-register']);
  }
}
