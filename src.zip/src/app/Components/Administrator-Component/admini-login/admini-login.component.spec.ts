import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminiLoginComponent } from './admini-login.component';

describe('AdminiLoginComponent', () => {
  let component: AdminiLoginComponent;
  let fixture: ComponentFixture<AdminiLoginComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminiLoginComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminiLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
