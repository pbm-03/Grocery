import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Product } from 'src/app/Entities/Product';
import { AdminServiceService } from 'src/app/Services/admin-service.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  products: Product[] = [];

  constructor(private route: Router, private service: AdminServiceService) {}

  ngOnInit() {
    this.getAllProducts(); // Fetch products when the component is initialized
  }

  getAllProducts() {
    this.service.getAllProducts().subscribe(
      (p) => {
        console.log("Products fetched:", p); // Check if products are returned correctly
        this.products = p;
      },
      (error) => {
        console.error("Error fetching products:", error); // Log any error
      }
    );
  }

  editProduct(productId: number) {
    this.route.navigate(['/update-products',productId]);
  }

  product:Product=new Product();
  deleteProduct(productId: number) {
    this.service.deleteProduct(productId).subscribe((p)=>this.product=p);
    alert("succeessfully Deleted!")
  }
}
