// cart.component.ts

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Cart } from 'src/app/Entities/Cart';
import { Product } from 'src/app/Entities/Product';
import { CustomerService } from 'src/app/Services/customer.service';
import { AuthserviceService } from 'src/app/Services/authservice.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  cart: Cart = new Cart();
  totalprice: number = 0;
  numberofitem: number = 1;

  userEmail: string | null = null;

  constructor(
    private service: CustomerService,
    private route: Router,
    private authService: AuthserviceService
  ) {}

  ngOnInit() {
    this.userEmail = this.authService.getUserEmail();
    if (this.userEmail) {
      this.viewCart(this.userEmail);
    }
  }

  continueShopping() {
    this.route.navigate(['']); // Navigate to home page
  }

  checkout() {
    this.route.navigate(['/order']); // Navigate to checkout page
  }

  public viewCart(customerEmail: string) {
    this.service.viewCart(customerEmail).subscribe((c) => {
      this.cart = c;
      this.calculateTotalPrice();
    });
  }

  // Method to add product to cart
  public addProductToCart(product: Product) {
    if (this.userEmail) {
      this.service.addToCart(this.userEmail, product).subscribe((cart) => {
        this.cart = cart; // Update the cart after adding the product
        this.calculateTotalPrice();
      });
    }
  }

  // Calculate the total price of products in the cart
  private calculateTotalPrice() {
    this.totalprice = 0;
    for (let p of this.cart.listOfProduct) {
      this.totalprice += p.price * this.numberofitem;
    }
  }

  // Method to remove product from the cart
  public removeFromCart(customerId: number, productId: number) {
    this.service.removeFromCart(customerId, productId).subscribe((c) => {
      this.cart = c; // Update the cart after removing the product
      this.calculateTotalPrice();
    });
  }
}
