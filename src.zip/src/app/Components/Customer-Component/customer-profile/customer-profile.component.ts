import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from 'src/app/Entities/Customer';
import { AuthserviceService } from 'src/app/Services/authservice.service';
import { CustomerService } from 'src/app/Services/customer.service';


@Component({
  selector: 'app-customer-profile',
  templateUrl: './customer-profile.component.html',
  styleUrls: ['./customer-profile.component.css']
})
export class CustomerProfileComponent implements OnInit{

  constructor(private route:Router,private authService:AuthserviceService,private service:CustomerService){

  }
  userEmail:string='';
  customer:Customer=new Customer();
  ngOnInit() {
    this.userEmail = this.authService.getUserEmail();
  }
  
  // Angular method to get customer details
public getCustomerDetails(userEmail: string) {
 this.service.getCustomerDetails(userEmail).subscribe((c)=>c);
}


  orderhistory(){
    this.route.navigate(['/order']);
  }
  editAddress(){
    this.route.navigate(['/'])
  }
  editProfile(){
    this.route.navigate(['/']);
  }
  supporthistory(){
    
  }

}
