import { Component } from '@angular/core';
import { Customer } from 'src/app/Entities/Customer';
import { CommonServiceService } from 'src/app/Services/common-service.service';
import { CustomerService } from 'src/app/Services/customer.service';
@Component({
  selector: 'app-customerprofile-update',
  templateUrl: './customerprofile-update.component.html',
  styleUrls: ['./customerprofile-update.component.css']
})
export class CustomerprofileUpdateComponent {
  constructor(private genderService: CommonServiceService,private service:CustomerService) { }
  gender:string;
  imgUrl:string;
  customer:Customer=new Customer();
  ngOnInit(): void {
    // Subscribe to the gender observable to get the latest value
    this.genderService.gender$.subscribe(gender => {
      this.gender = gender; // Assign the value to the component's gender variable
    });


   
    if(this.gender.toLocaleLowerCase('female')){
      this.imgUrl='.\assets\woman.png';
    }
    else{
      this.imgUrl='Grocery-Store\src\assets\man.png';
    }

}
  public getCustomerById(customeremail:string){
    this.service.getCustomerDetails(this.customer.email).subscribe((c)=>this.customer=c);
  }
}
