import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerprofileUpdateComponent } from './customerprofile-update.component';

describe('CustomerprofileUpdateComponent', () => {
  let component: CustomerprofileUpdateComponent;
  let fixture: ComponentFixture<CustomerprofileUpdateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerprofileUpdateComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CustomerprofileUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
