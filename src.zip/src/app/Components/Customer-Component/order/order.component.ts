import { Component, OnInit } from '@angular/core';
import { Cart } from 'src/app/Entities/Cart';
import { Order } from 'src/app/Entities/Order';
import { AdminServiceService } from 'src/app/Services/admin-service.service';
import { AuthserviceService } from 'src/app/Services/authservice.service';
import { CustomerService } from 'src/app/Services/customer.service';
import { OrderServiceService } from 'src/app/Services/order-service.service';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit{
  constructor(private service:OrderServiceService,private adminservice:AdminServiceService,private cartService:CustomerService,
              private authService:AuthserviceService){}

  order:Order=new Order();
  cart:Cart=new Cart();
  flag:boolean=false;
  shipping:number;

  userEmail:string;
  ngOnInit() {
    this.userEmail = this.authService.getUserEmail();
    this.cartService.viewCart(this.userEmail).subscribe((c)=>this.cart=c);
  }


  public placeOrder(orderplaced:Order,customerId:number){
    this.service.placeOrder(orderplaced,customerId).subscribe((o)=>this.order=o);
    orderplaced.listOfProducts=this.cart.listOfProduct;
  
  }
  public removeOrder(customerId:number){
    this.service.removeOrder(customerId).subscribe((o)=>this.flag=o);
  }
  public viewAdminConfig(){
    this.adminservice.getAdminConfig(this.order.payment.paymentMethod).subscribe((p)=>this.shipping=p);
  }


}
