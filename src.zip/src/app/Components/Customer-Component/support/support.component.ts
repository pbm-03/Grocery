import { Component } from '@angular/core';
import { Support } from 'src/app/Entities/Support';

@Component({
  selector: 'app-support',
  templateUrl: './support.component.html',
  styleUrls: ['./support.component.css']
})
export class SupportComponent {
  constructor() { }
 
  support:Support;

  issuetype:string='';
  name:string='';
  email:string='';
  issue:string='';
  submit():void {

    console.log('Form submitted!');
    // Implement your form submission logic here, e.g., send the form data to the backend API.
  }
}
