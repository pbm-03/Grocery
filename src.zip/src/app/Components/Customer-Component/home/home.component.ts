import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Cart } from 'src/app/Entities/Cart';
import { Product } from 'src/app/Entities/Product';
import { Category } from 'src/app/Entities/Category';
import { AuthserviceService } from 'src/app/Services/authservice.service';
import { CustomerService } from 'src/app/Services/customer.service';
import { HomeServiceService } from 'src/app/Services/home-service.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  searchText: string = '';
  selectedCategory: string = '';  // Holds the selected category name
  products: Product[] = [];
  filteredProducts: Product[] = [];
  categories: Category[] = [];
  cart: Cart = new Cart();
  userEmail: string | null = null;  // Store logged-in user's email

  constructor(
    private service: HomeServiceService, 
    private route: Router,
    private authService: AuthserviceService,
    private cartService: CustomerService
  ) {}

  ngOnInit() {
    this.getAllProducts();
    this.getAllCategory();
    this.userEmail = this.authService.getUserEmail();
  }

  get isLoggedIn(): boolean {
    return this.authService.isLoggedIn();
  }

  // Fetch all products
  public getAllProducts() {
    this.service.getAllProducts().subscribe((p) => {
      this.products = p;
      this.filteredProducts = p;  // Initially show all products
    });
  }

  // Fetch all categories
  public getAllCategory() {
    this.service.getAllCategory().subscribe((c) => {
      this.categories = c;
    });
  }

  // Filter products based on selected category and search text
  onCategorySelect() {
    this.filterProducts();
  }

  // Filter products based on search text
  onSearchChange() {
    this.filterProducts();
  }

  private filterProducts() {
    let filtered = this.products;

    // Filter by search text
    if (this.searchText) {
      filtered = filtered.filter(product => {
        const productName = product.productName ? product.productName.toLowerCase() : '';
        return productName.includes(this.searchText.toLowerCase());
      });
    }

    // Filter by category if a category is selected
    if (this.selectedCategory) {
      filtered = filtered.filter(product => {
        const categoryName = product.category ? product.category.categoryName : '';
        return categoryName === this.selectedCategory;
      });
    }

    this.filteredProducts = filtered;
  }

  // Add to cart method
  public addtocart(customerEmail: string, product: Product) {
    if (customerEmail && product) {
      this.cartService.addToCart(customerEmail, product).subscribe((cart) => {
        this.cart = cart; // Update the cart object after adding the product
        console.log('Product added to cart:', this.cart);
      });
    } else {
      console.log('User email or product data is missing!');
    }
  }

  logout(): void {
    this.authService.logout();
    this.route.navigate(['/login']);
  }
}
