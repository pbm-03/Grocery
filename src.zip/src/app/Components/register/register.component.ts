import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from 'src/app/Entities/Customer';
import { CommonServiceService } from 'src/app/Services/common-service.service';
import { CustomerService } from 'src/app/Services/customer.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  // Declare and initialize customer object
  customer: Customer = new Customer();  // Initializing customer object

  constructor(private route: Router,private service:CustomerService,private genderService: CommonServiceService) { 
    
  }

  // Declare the variables for ngModel binding
  name: string = '';
  email: string = '';
  mobilenumber: string = '';
  password: string = '';
  gender:string='';
  onSubmit() {
    // Assign the values to the customer object
    this.customer.customerName = this.name;
    this.customer.email = this.email;
    this.customer.mobileNumber = this.mobilenumber;
    this.customer.password = this.password;
    this.genderService.setGender(this.gender);
  
    // Call customerRegister and handle the response
    this.service.customerRegister(this.customer).subscribe(
      (response) => {
        // Handle the successful registration
        console.log('Registration successful', response);
        this.route.navigate(['/login']);
      },
      (error) => {
        // Handle errors here
        console.error('Registration failed', error);
      }
    );
  }
  
}
