import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminConfig } from 'src/app/Entities/AdminConfig';
import { AdminServiceService } from 'src/app/Services/admin-service.service';

@Component({
  selector: 'app-system-config',
  templateUrl: './system-config.component.html',
  styleUrls: ['./system-config.component.css']
})
export class SystemConfigComponent implements OnInit{
  // Define variables to bind to the input fields
  constructor(private route:Router,private service:AdminServiceService){

  }
  ngOnInit(): void {
      this.getAllConfig();
  }
  configid: number;
  deliveryfee: number;
  taxes: number;
  paymentMethods: string = '';
  config:AdminConfig=new AdminConfig();
  // Method to handle form submission
  set(): void {
    this.config.adminConfigId=this.configid;
    this.config.deliveryFee=this.deliveryfee;
    this.config.paymentMethods=this.paymentMethods;
    this.config.taxes=this.taxes;

    this.service.setConfig(this.config).subscribe((c)=>this.config=c);
    if(this.config!=null)
    alert("New Config Set REFRESH TO SEE THE UPDATED DATA");
  }
  configs:AdminConfig[]=[]
  getAllConfig(){
    this.service.getAllConfig().subscribe((c)=>this.configs=c);
  }
  deleteconfig(id:number){
    this.service.deleteConfigById(id).subscribe((c)=>this.config=c);
    console.log(id);
    alert("Config with id "+id+" deleted successfully REFRESH THE PAGE FOR UPDATED DATA");
  }

}
