import { Component } from '@angular/core';
import { Customer } from 'src/app/Entities/Customer';
import { AdminServiceService } from 'src/app/Services/admin-service.service';

@Component({
  selector: 'app-allcustomers',
  templateUrl: './allcustomers.component.html',
  styleUrls: ['./allcustomers.component.css']
})
export class AllcustomersComponent {
  customer:Customer[]=[];
  constructor(private adminservice:AdminServiceService){}
  customerid:number;
 
 
  ngOnInit(): void {
    this.adminservice.allcustomers().subscribe((c)=>this.customer=c);
  }
  // onSubmit(signupForm: NgForm): void {
  //   if (signupForm.valid) {
  //     this.adminiService.administratorRegister(this.admistrator).subscribe((p)=> this.adminis=p);
  //     alert("Registration successful")
  //   }
  // }
 
  // editCustomer():void{
 
  // }
  deleteCustomer(customerId:Number):void{
    for(let c of this.customer){
      if(c.customerId == customerId)
      {
        this.customerid=c.customerId;
      }
    }
    this.adminservice.deleteCustomer(this.customerid).subscribe((c)=>this.customer=c);
    alert("Customer with Customer iD "+this.customerid+ "deleted successfuly for UPDATED DATA REFRESH THE PAGE");
 
  }
}
