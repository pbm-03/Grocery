import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Product } from 'src/app/Entities/Product';
import { AdminServiceService } from 'src/app/Services/admin-service.service';

@Component({
  selector: 'app-update-products',
  templateUrl: './update-products.component.html',
  styleUrls: ['./update-products.component.css']
})
export class UpdateProductsComponent implements OnInit {
  
  productId: number;
  product: Product = new Product(); // initialize the product
  products:Product[]=[];
  constructor(private route: ActivatedRoute, private service: AdminServiceService,private router:Router) { }

  ngOnInit(): void {
    this.productId = +this.route.snapshot.paramMap.get('productid');  // Get the productId from the URL
    console.log("Product ID:", this.productId);
    this.service.getProductById(this.productId).subscribe((p)=>this.product=p);
    console.log(this.product.productName);
  }

  // Submit the updated product
  updateProduct() {
    this.service.editProduct(this.product).subscribe(
      (updatedProduct) => {
        this.product = updatedProduct;
        console.log("Product updated:", this.product);
        alert("Product Updated");
        this.router.navigate(['/products']);
      },
      (error) => {
        console.error("Error updating product:", error);
      }
    );
  }
}
