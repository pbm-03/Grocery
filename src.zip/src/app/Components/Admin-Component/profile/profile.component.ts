import { Component } from '@angular/core';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent {
  adminId: string = '';
  adminName: string = '';
  adminContact: string = '';
  adminEmail: string = '';
 
  ngOnInit(): void {
    // Get the admin data from localStorage
    this.adminId = localStorage.getItem('adminId') || '';
    this.adminName = localStorage.getItem('adminName') || '';
    this.adminContact = localStorage.getItem('adminContact') || '';
    this.adminEmail = localStorage.getItem('adminEmail') || '';
  }
 
  // Optional: Clear data when logging out
  onLogout(): void {
    localStorage.removeItem('adminId');
    localStorage.removeItem('adminName');
    localStorage.removeItem('adminContact');
    localStorage.removeItem('adminEmail');
  }
  
}
