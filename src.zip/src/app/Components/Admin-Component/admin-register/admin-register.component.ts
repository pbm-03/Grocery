import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Admin } from 'src/app/Entities/Admin';
import { AdminServiceService } from 'src/app/Services/admin-service.service';
import { AuthserviceService } from 'src/app/Services/authservice.service';

@Component({
  selector: 'app-admin-register',
  templateUrl: './admin-register.component.html',
  styleUrls: ['./admin-register.component.css']
})
export class AdminRegisterComponent {

  constructor(private authService: AdminServiceService,private route:Router) { }
 
  // The onSubmit method will now use the AuthService to send form data
  adminData:Admin=new Admin();
  onSubmit(signupForm: NgForm): void {
    if (signupForm.valid) {
      const userData = signupForm.value;  // Get form data
      console.log('Submitting user data:', userData);  // Add debug log for user data
      this.authService.register(userData).subscribe(
        response => {
          console.log('Registration successful!', response);
          alert('Data submitted successfully');
          signupForm.reset();  // Reset form after successful submission
          this.route.navigate(['admin-login']);
        },
        error => {
          console.error('Registration error', error);
          alert('Registration failed');
        }
      );
    } else {
      console.warn('Form is invalid:', signupForm);
    }
  }
}
