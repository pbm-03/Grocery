import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Admin } from 'src/app/Entities/Admin';
import { AdminServiceService } from 'src/app/Services/admin-service.service';
import { CustomerService } from 'src/app/Services/customer.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  admin: Admin = new Admin();  // Initialize admin object
  adminEmail: string = '';  // Default to empty string

  constructor(
    private adminService: AdminServiceService,
    private route: Router,
    private customerService: CustomerService
  ) {}

  ngOnInit(): void {
    this.adminEmail = this.adminService.getAdminEmail();  // Get admin email from service
    if (this.adminEmail) {
      this.getAdminByEmail(this.adminEmail);  // If email is found, fetch admin details
    } else {
      console.error('Admin email not found');
    }
  }

  // Fetch admin details based on email
  getAdminByEmail(adminEmail: string): void {
    this.adminService.getAdminByEmail(adminEmail).subscribe(
      (a) => {
        this.admin = a;  // Assign fetched admin details to the admin object
      },
      (error) => {
        console.error('Error fetching admin data:', error);  // Handle any errors
      }
    );
  }

  // Navigation methods for actions
  handleOrders(): void {
    this.route.navigate(['/allorders']);
  }

  handleProducts(): void {
    this.route.navigate(['/products']);
  }

  handleCustomers(): void {
    this.route.navigate(['/allcustomers']);
  }

  handleAdminConfig(): void {
    this.route.navigate(['/admin-config']);
  }
}
