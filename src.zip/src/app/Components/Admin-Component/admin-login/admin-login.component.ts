import { Component } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminServiceService } from 'src/app/Services/admin-service.service';
import { AuthserviceService } from 'src/app/Services/authservice.service';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent {
  signInForm: FormGroup;
  errorMessage: string = '';

  constructor(private fb: FormBuilder, private authService: AdminServiceService, private router: Router) {
    this.signInForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required]]
    });
  }

  // Handle login form submission
  onSubmit(): void {
    if (this.signInForm.valid) {
      const email = this.signInForm.value.email;
      const password = this.signInForm.value.password;

      // Call the login service and subscribe to the response
      this.authService.login(email, password).subscribe({
        next: (data) => {
          // Save admin data to localStorage after successful login
          localStorage.setItem('adminId', data.adminId);
          localStorage.setItem('adminName', data.adminName);
          localStorage.setItem('adminContact', data.adminContact);
          localStorage.setItem('adminEmail', data.adminEmail);

          // Redirect to homepage after successful login
          this.router.navigate(['/dashboard']); // Redirect to the home page
        },
        error: (error) => {
          this.errorMessage = 'Invalid login credentials'; // Show error message if login fails
          console.error('Login error:', error);
        }
      });
    } else {
      console.log('Form is not valid');
    }
  }

  // Redirect to the register page for new users
  newregister(): void {
    this.router.navigate(['/register']);
  }
}
