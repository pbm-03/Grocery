import { Component } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Customer } from 'src/app/Entities/Customer';
import { CustomerService } from 'src/app/Services/customer.service';
import { AuthserviceService } from 'src/app/Services/authservice.service'; // Import AuthService

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  signInForm: FormGroup;
  customer: Customer;

  constructor(private fb: FormBuilder, private router: Router, private service: CustomerService, private authService: AuthserviceService) {
    this.signInForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required]]
    });
  }

  onSubmit(): void {
    if (this.signInForm.valid) {
      const email = this.signInForm.value.email;
      const password = this.signInForm.value.password;

      // Call the login service and subscribe to the response
      this.service.customerLogin(email, password).subscribe(
        (customer) => {
          // If the customer object is returned, validate the email and password
          if (customer && customer.email === email && customer.password === password) {
            console.log('Login successful');
            this.authService.setLoginStatus(true,customer.email); // Set login status in AuthService
            this.router.navigate(['/']); // Redirect to home page after successful login
          } else {
            console.log('Invalid credentials');
            // Optionally, show an error message to the user here
          }
        },
        (error) => {
          console.error('Login failed', error);
          // Handle error (e.g., invalid email/password, server error)
        }
      );
    } else {
      console.log('Form is not valid');
    }
  }
  newregister(){
    this.router.navigate(['/register']);
  }
}
