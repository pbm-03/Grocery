import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './Components/login/login.component';
import { RegisterComponent } from './Components/register/register.component';
import { AboutComponent } from './Components/about/about.component';
import { AnalyticsComponent } from './Components/Admin-Component/analytics/analytics.component';
import { DashboardComponent } from './Components/Admin-Component/dashboard/dashboard.component';
import { ProfileComponent } from './Components/Admin-Component/profile/profile.component';
import { SystemConfigComponent } from './Components/Admin-Component/system-config/system-config.component';
import { ProductsComponent } from './Components/Administrator-Component/products/products.component';
import { CartComponent } from './Components/Customer-Component/cart/cart.component';
import { HomeComponent } from './Components/Customer-Component/home/home.component';
import { OrderComponent } from './Components/Customer-Component/order/order.component';
import { AdminiDashboardComponent } from './Components/Administrator-Component/admini-dashboard/admini-dashboard.component';
import { AdminiProfileComponent } from './Components/Administrator-Component/admini-profile/admini-profile.component';
import { AdminiSupportComponent } from './Components/Administrator-Component/admini-support/admini-support.component';
import { CustomerProfileComponent } from './Components/Customer-Component/customer-profile/customer-profile.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { SupportComponent } from './Components/Customer-Component/support/support.component';
import { AdminLoginComponent } from './Components/Admin-Component/admin-login/admin-login.component';
import { AdminRegisterComponent } from './Components/Admin-Component/admin-register/admin-register.component';
import { AdminiLoginComponent } from './Components/Administrator-Component/admini-login/admini-login.component';
import { AdminiRegisterComponent } from './Components/Administrator-Component/admini-register/admini-register.component';
import { CustomerprofileUpdateComponent } from './Components/Customer-Component/customerprofile-update/customerprofile-update.component';
import { AllordersComponent } from './Components/Admin-Component/allorders/allorders.component';
import { AllcustomersComponent } from './Components/Admin-Component/allcustomers/allcustomers.component';
import { UpdateProductsComponent } from './Components/Admin-Component/update-products/update-products.component';


@NgModule({
  declarations: [
    LoginComponent,
    RegisterComponent,
    AboutComponent,
    AnalyticsComponent,
    DashboardComponent,
    ProductsComponent,
    ProfileComponent,
    SystemConfigComponent,
    CartComponent,
    HomeComponent,
    OrderComponent,
    AdminiDashboardComponent,
    AdminiProfileComponent,
    AdminiSupportComponent,
    CustomerProfileComponent,
    AppComponent,
    SupportComponent,
    AdminLoginComponent,
    AdminRegisterComponent,
    AdminiLoginComponent,
    AdminiRegisterComponent,
    CustomerprofileUpdateComponent,
    AllordersComponent,
    AllcustomersComponent,
    UpdateProductsComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,        // Ensure FormsModule is here
    HttpClientModule,
    ReactiveFormsModule // For Reactive Forms if needed
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
