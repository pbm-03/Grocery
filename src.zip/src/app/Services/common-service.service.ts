import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';  


@Injectable({
  providedIn: 'root'
})
export class CommonServiceService {

  constructor() { }
  private genderSubject = new BehaviorSubject<string>(''); 
  gender$ = this.genderSubject.asObservable(); 


  setGender(gender: string): void {
    this.genderSubject.next(gender);
  }


  getGender(): string {
    return this.genderSubject.value;
  }
}
