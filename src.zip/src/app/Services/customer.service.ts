import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { URLS } from '../Entities/URLS';
import { Observable,switchMap,tap } from 'rxjs';
import { Customer } from '../Entities/Customer';
import { Product } from '../Entities/Product';
import { AuthserviceService } from './authservice.service';  // Import AuthserviceService

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  // adminLogin(email: any, password: any) {
  //   throw new Error('Admin Login Error.');
  // }

  urls: URLS = new URLS();
  customerURL: string = this.urls.customerURL;
  cartURL: string = this.urls.cartURL;

  constructor(private http: HttpClient, private authService: AuthserviceService) { }


  public customerLogin(email: string, password: string): Observable<Customer> {
    return this.http.get<Customer>(`${this.customerURL}/login/${email}/${password}`)
      .pipe(
        // After successful login, store the user's email in AuthService
        tap(customer => {
          if (customer) {
            this.authService.setLoginStatus(true, customer.email);  // Storing login status and email
          }
        })
      );
  }

  public customerRegister(customer: Customer): Observable<any> {
    return this.http.post<any>(`${this.customerURL}/register`, customer);
  }

  public getCustomerDetails(customerEmail: string): Observable<any> {
    return this.http.get<any>(`${this.customerURL}/customerdetails/${customerEmail}`);
  }
  


  // Cart related methods...
  public viewCart(customeremail: string): Observable<any> {
    return this.http.get<any>(`${this.cartURL}/viewcart/${customeremail}`);
  }

  public addToCart(customeremail: string, product: Product): Observable<any> {
    // Fetch current cart
    return this.http.get<any>(`${this.cartURL}/viewcart/${customeremail}`).pipe(
      switchMap((cart) => {
        const existingProduct = cart.listOfProduct.find((item: any) => item.productId === product.productId);
  
        if (existingProduct) {
          // Increase the quantity of the existing product
          existingProduct.qnt++;
        } else {
          // Add the new product with quantity 1
          product.stockQnt = 1;
          cart.listOfProduct.push(product);
        }
  
        // Now update the cart
        return this.http.post<any>(`${this.cartURL}/addtocart/${customeremail}`, cart).pipe(
          tap(() => {
            // Return the updated cart after it is saved in the backend
            return cart;
          })
        );
      })
    );
  }
  
  
  public removeFromCart(customerId: number, productId: number): Observable<any> {
    return this.http.delete<any>(`${this.cartURL}/removefromcart/${productId}/${customerId}`);
  }
  
}
