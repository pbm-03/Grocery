import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { URLS } from '../Entities/URLS';
import { Observable } from 'rxjs';
import { Order } from '../Entities/Order';

@Injectable({
  providedIn: 'root'
})
export class OrderServiceService {

  url:URLS=new URLS();
  orderURL:string=this.url.orderURL;
  constructor(private http:HttpClient) { }

  public placeOrder(order:Order,customerId:number):Observable<any>{
    return this.http.post<any>(this.orderURL+"/placeorder/"+customerId,order);
  }
  public removeOrder(customerId:number):Observable<any>{
    return this.http.delete<any>(this.orderURL+"/removeorder/"+customerId);
  }

}
