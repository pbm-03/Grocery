import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { URLS } from '../Entities/URLS';
import { AdminConfig } from '../Entities/AdminConfig';
import { Product } from '../Entities/Product';
import { Customer } from '../Entities/Customer';

@Injectable({
  providedIn: 'root'
})
export class AdminServiceService {

  url: URLS = new URLS();
  adminUrl: string = this.url.adminURL;
  productUrl:string=this.url.productURL;
  customerUrl:string=this.url.customerURL;
  adminEmail:string;


  constructor(private http: HttpClient) { }

  // Fixed URL format for login
  login(email: string, password: string): Observable<any> {
    const userData = { email, password };
    this.adminEmail=email;
    return this.http.get(this.adminUrl + "/login/" + email + "/" + password); // Fixed URL
    
  }
  getAdminEmail(){
    return this.adminEmail;
  }
  public getAdminByEmail(adminEmail):Observable<any>{
    return this.http.get<any>(this.adminUrl+"/getadmin/"+adminEmail);
  }
  // Get admin configuration by payment method
  public getAdminConfig(paymentMethod: string): Observable<any> {
    return this.http.get<any>(this.adminUrl + "/viewadminconfig/" + paymentMethod); // Fixed URL format
  }

  // Register admin
  register(userData: any): Observable<any> {
    return this.http.post(this.adminUrl + "/register", userData, {
      headers: { 'Content-Type': 'application/json' }
    });
  }

  // Set configuration
  public setConfig(config: AdminConfig): Observable<any> {
    return this.http.post<any>(this.adminUrl + "/addconfig", config);
  }

  // Get all admin configurations
  public getAllConfig(): Observable<any> {
    return this.http.get<any>(this.adminUrl + "/viewallconfig");
  }
  public deleteConfigById(id:number):Observable<any>
  {
    return this.http.delete<any>(this.adminUrl+"/deleteconfig/"+id);
  }

  public getAllProducts():Observable<any>{
    return this.http.get<any>(this.productUrl+"/viewproducts");
  }
  public deleteProduct(productId:number):Observable<any>{
    return this.http.delete<any>(this.productUrl+"/deleteproduct/"+productId);
  }
  public editProduct(product:Product):Observable<any>{
    return this.http.put<any>(this.productUrl+"/updateproduct",product);
  }
  public getProductById(productId:number){
    return this.http.get<any>(this.productUrl+"/getproductbyId/"+productId);
  }
  


  public allcustomers(): Observable<any>{
    return this.http.get(this.customerUrl+"/getAllCustomerDetails")
  }
 
  public updateCustomers(customer:Customer):Observable<any>{
    return this.http.put(this.customerUrl+ "/updateDetails",customer,{responseType: 'json'})
  }
 
 
  public deleteCustomer(customerId: number): Observable<any> {
    return this.http.delete(`${this.customerUrl}/deleteByCustomerID/${customerId}`);
  }



}
