import { TestBed } from '@angular/core/testing';

import { AdminiServiceService } from './admini-service.service';

describe('AdminiServiceService', () => {
  let service: AdminiServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AdminiServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
