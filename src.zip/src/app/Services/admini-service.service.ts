import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { URLS } from '../Entities/URLS';
import { Observable } from 'rxjs';
import { Administrator } from '../Entities/Administrator';

@Injectable({
  providedIn: 'root'
})
export class AdminiServiceService {


  constructor(private http:HttpClient) { }

  url:URLS=new URLS();
  adminiUrl:string=this.url.adminiURL;
  adminiemail:string;

  public administratorRegister(admini: Administrator): Observable<any> {
    return this.http.post(this.adminiUrl+"/register", admini,{responseType: 'json'});
  }
  public administratorLogin(email: string, password: string): Observable<any> {
    this.adminiemail=email;
    return this.http.get(this.adminiUrl +"/login"+ "/" + email + "/" + password);
  }
  public getEmail(){
    return this.adminiemail;
  }
  public getAdminiByEmail(adminiemail){
    return this.http.get<any>(this.adminiUrl+"/getadmini/"+adminiemail);
  }

}
