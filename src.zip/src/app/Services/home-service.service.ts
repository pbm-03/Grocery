import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { URLS } from '../Entities/URLS';
import { Observable } from 'rxjs';
import { Category } from '../Entities/Category';

@Injectable({
  providedIn: 'root'
})
export class HomeServiceService {

  urls:URLS=new URLS();
  productURL:string=this.urls.productURL;
  constructor(private http:HttpClient) { }

  public getAllProducts():Observable<any>{
    return this.http.get<any>(this.productURL+"/viewproducts");
  }
  public getAllCategory():Observable<any>{
    return this.http.get<any>(this.productURL+"/viewallcategories");
  }
  public searchByCatagories(category:string):Observable<any>{
    return this.http.get<any>(this.productURL+"/searchbycatagory/"+category);
  }
  public searchByKeyword(keyword:string):Observable<any>{
    return this.http.get<any>(this.productURL+"/searchbykeyword/"+keyword);
  }
  public searchByPrice(price1:number,price2:number):Observable<any>{
    return this.http.get<any>(this.productURL+"/serachbyprice/"+price1+"/"+price2);
  }
}
