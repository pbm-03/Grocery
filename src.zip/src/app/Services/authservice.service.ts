import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { URLS } from '../Entities/URLS';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AuthserviceService {
  private isAuthenticated = false;
  private userEmail: string | null = null;
  url:URLS=new URLS();
  adminUrl:string=this.url.adminURL;


  constructor(private http:HttpClient) {
    // Retrieve the initial login state and email from localStorage (or any other source)
    const storedState = localStorage.getItem('isLoggedIn');
    const storedEmail = localStorage.getItem('userEmail');
    
    if (storedState && storedEmail) {
      this.isAuthenticated = JSON.parse(storedState);
      this.userEmail = storedEmail;
    }
  }

  // Returns whether the user is logged in or not
  isLoggedIn(): boolean {
    return this.isAuthenticated;
  }

  // Set login status and email (called when user logs in)
  setLoginStatus(status: boolean, email: string): void {
    this.isAuthenticated = status;
    this.userEmail = email;
    localStorage.setItem('isLoggedIn', JSON.stringify(status));
    localStorage.setItem('userEmail', email);
  }

  // Get the stored user's email
  getUserEmail(): string | null {
    return this.userEmail;
  }

  // Clear login status and email (called when user logs out)
  logout(): void {
    this.isAuthenticated = false;
    this.userEmail = null;
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('userEmail');
  }



  //Pravalika Part
  register(adminData: any): Observable<any> {
    return this.http.post(this.adminUrl, adminData, {
      headers: { 'Content-Type': 'application/json' }
    });
  }

  login(email: string, password: string): Observable<any> {
    const userData = { email, password };
    return this.http.get(this.adminUrl + "/" + email + "/" + password);
  }




  registerAdmin(userData: any): Observable<any> {
    return this.http.post(this.adminUrl, userData, {
      headers: { 'Content-Type': 'application/json' }
    });
  }
 
  // Login method to check user credentials
  loginadmin(email: string, password: string): Observable<any> {
    const userData = { email, password };
    return this.http.get(this.adminUrl + "/" + email + "/" + password);
  }
 
  getAdminDetails(email: string, password: string): Observable<any> {
    return this.http.get(this.adminUrl + "/" + email + "/" + password);
  }

}
