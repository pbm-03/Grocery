package com.mphasis.GroceryStore.entities;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
 
@Entity
public class Support {
 
	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	int supportId;
	String issueType;
	String issueDescription;
	String issueStatus;
	LocalDate createdDate;
	@ManyToOne
	@JoinColumn(name = "customer_id")
	Customer customer;
	@ManyToOne
	@JoinColumn(name = "administrator_id")
	Administrator administrator;
	public Support() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Support(int supportId, String issueType, String issueDescription, String issueStatus, LocalDate createdDate,
			Customer customer, Administrator administrator) {
		super();
		this.supportId = supportId;
		this.issueType = issueType;
		this.issueDescription = issueDescription;
		this.issueStatus = issueStatus;
		this.createdDate = createdDate;
		this.customer = customer;
		this.administrator = administrator;
	}
	public int getSupportId() {
		return supportId;
	}
	public void setSupportId(int supportId) {
		this.supportId = supportId;
	}
	public String getIssueType() {
		return issueType;
	}
	public void setIssueType(String issueType) {
		this.issueType = issueType;
	}
	public String getIssueDescription() {
		return issueDescription;
	}
	public void setIssueDescription(String issueDescription) {
		this.issueDescription = issueDescription;
	}
	public String getIssueStatus() {
		return issueStatus;
	}
	public void setIssueStatus(String issueStatus) {
		this.issueStatus = issueStatus;
	}
	public LocalDate getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(LocalDate createdDate) {
		this.createdDate = createdDate;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Administrator getAdministrator() {
		return administrator;
	}
	public void setAdministrator(Administrator administrator) {
		this.administrator = administrator;
	}
	@Override
	public String toString() {
		return "Support [supportId=" + supportId + ", issueType=" + issueType + ", issueDescription=" + issueDescription
				+ ", issueStatus=" + issueStatus + ", createdDate=" + createdDate + ", customer=" + customer
				+ ", administrator=" + administrator + "]";
	}
	
}