package com.mphasis.GroceryStore.Iservice;

import java.util.List;

import com.mphasis.GroceryStore.entities.AdminConfig;

public interface IAdminConfigService {

	public AdminConfig addAdminConfig(AdminConfig adminConfig);
	public boolean deleteAdminConfig(int adminConfigId);
	public AdminConfig modifyAdminConfig(AdminConfig adminConfig);
	public AdminConfig viewAdminConfigByPaymentMethod(String paymentMethod);
	public List<AdminConfig> getAllAdminConfig();
}
