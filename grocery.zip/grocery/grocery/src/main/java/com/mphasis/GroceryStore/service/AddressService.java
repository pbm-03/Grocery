package com.mphasis.GroceryStore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.GroceryStore.Iservice.IAddressService;
import com.mphasis.GroceryStore.Repository.IAddressRepository;
import com.mphasis.GroceryStore.Repository.ICustomerRepository;
import com.mphasis.GroceryStore.entities.Address;
import com.mphasis.GroceryStore.entities.AddressDetails;

@Service
public class AddressService implements IAddressService{
	
	
	@Autowired
	IAddressRepository addressRepository;
	@Autowired
	ICustomerRepository customerRepository;
	@Override
	
	
	
	public Address UpdateAddress(AddressDetails addressDetails,int customerId) {
		// TODO Auto-generated method stub
		if(addressRepository.findByCustomerId(customerId)!=null) {
			Address address=new Address();
			address.setArea(addressDetails.getArea());
			address.setBulding(addressDetails.getBulding());
			address.setCity(addressDetails.getCity());
			address.setPin(addressDetails.getPin());
			address.setState(addressDetails.getState());
			address.setStreet(addressDetails.getStreet());
			address.setCustomer(customerRepository.findById(customerId).get());
			addressRepository.save(address);
			return address;
		}
		return null;
	}
	@Override
	public Address addAddress(AddressDetails addressDetails,int customerId) {
		// TODO Auto-generated method stub
		Address address=new Address();
		address.setArea(addressDetails.getArea());
		address.setBulding(addressDetails.getBulding());
		address.setCity(addressDetails.getCity());
		address.setPin(addressDetails.getPin());
		address.setState(addressDetails.getState());
		address.setStreet(addressDetails.getStreet());
		address.setCustomer(customerRepository.findById(customerId).get());
		return addressRepository.save(address);
	}
	@Override
	public boolean deleteAddress(Address address) {
		// TODO Auto-generated method stub
		addressRepository.delete(address);
		return true;
	}

	
}
