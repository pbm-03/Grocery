package com.mphasis.GroceryStore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.GroceryStore.entities.Category;
import com.mphasis.GroceryStore.entities.CategoryDetails;
import com.mphasis.GroceryStore.entities.Product;
import com.mphasis.GroceryStore.service.ProductService;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/product")
public class ProductController {

	@Autowired
	ProductService productService;
	
	@GetMapping("/viewproducts")
	public List<Product> viewProducts(){
		return productService.viewProducts();
	}
	
	@GetMapping("/searchbycatagory/{p1}")
	public List<Product> searchByCatagories(@PathVariable("p1") String catagoryName){
		return productService.searchByCatagories(catagoryName);
	}
	@GetMapping("/serachbyprice/{p1}/{p2}")
	public List<Product> searchByPrice(@PathVariable("p1") double price1,@PathVariable("p2") double price2){
		return productService.searchByPrice(price1, price2);
	}
	@GetMapping("/searchbykeyword/{p1}")
	public List<Product> searchByKeyword(@PathVariable("p1") String productName){
		return productService.searchByKeyword(productName);
	}
	
	
	@PostMapping("/addcategory")
	public boolean addCategory(@RequestBody CategoryDetails categoryDetails) {
		if(productService.addNewCategory(categoryDetails)!=null)
			return true;
		return false;
	}
	@GetMapping("/viewallcategories")
	public List<Category> viewAllCategories(){
		return productService.viewAllCategory();
	}
	
	@PostMapping("/addproduct")
	public Product addProduct(@RequestBody Product product) {
		return productService.addProduct(product);
	}
	@PutMapping("/updateproduct")
	public Product updateProduct(@RequestBody Product product) {
		return productService.updateProduct(product);
	}
	@DeleteMapping("/deleteproduct/{p1}")
	public Product removeProduct(@PathVariable("p1")int productsId) {
		return productService.removeProduct(productsId);
	}
	@GetMapping("/getproductbyId/{p1}")
	public Product getProductById(@PathVariable("p1")int productId) {
		return productService.getProductById(productId);
	}
}
