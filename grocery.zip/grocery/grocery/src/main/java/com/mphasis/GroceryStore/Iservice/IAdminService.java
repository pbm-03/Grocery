package com.mphasis.GroceryStore.Iservice;


import com.mphasis.GroceryStore.entities.Admin;

public interface IAdminService {
	public Admin login(String email,String password);
	public Admin register(Admin admin);
	public Admin getAdminByEmail(String email);
}
