package com.mphasis.GroceryStore.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.GroceryStore.Iservice.ISupportService;
import com.mphasis.GroceryStore.Repository.IAdministratorRepository;
import com.mphasis.GroceryStore.Repository.ICustomerRepository;
import com.mphasis.GroceryStore.Repository.ISupportRepository;
import com.mphasis.GroceryStore.entities.Support;
import com.mphasis.GroceryStore.entities.SupportRequest;

@Service
public class SupportService implements ISupportService{

	
	
	@Autowired
	ISupportRepository supportRepository;
	@Autowired
	IAdministratorRepository administratorRepository;
	@Autowired
	ICustomerRepository customerRepository;
	
	
	@Override
	public Support addSupport(SupportRequest supportRequest) {
		// TODO Auto-generated method stub
		Support tempSupport=new Support();
		tempSupport.setCreatedDate(LocalDate.now());
		tempSupport.setIssueDescription(supportRequest.getDescription());
		tempSupport.setIssueStatus(supportRequest.getStatus());
		tempSupport.setIssueType(supportRequest.getIssueType());
		tempSupport.setAdministrator(administratorRepository.findById(supportRequest.getAdministratorId()).get());
		tempSupport.setCustomer(customerRepository.findById(supportRequest.getCustomerId()).get());
		return tempSupport;
	}

	@Override
	public List<Support> findByCustomerId(int customerId) {
		// TODO Auto-generated method stub
		return customerRepository.findById(customerId).get().getListOfSupport();
	}

	@Override
	public List<Support> findByAdministratorId(int adminstratorId) {
		// TODO Auto-generated method stub
		return administratorRepository.findById(adminstratorId).get().getListOfSupport();
	}

}
