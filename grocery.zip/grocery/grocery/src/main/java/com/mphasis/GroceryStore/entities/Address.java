package com.mphasis.GroceryStore.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
 
@Entity
public class Address {
	@ManyToOne
	@JoinColumn(name = "customer_id")
	Customer customer;
	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	int addressId;
	String area;
	String pin;
	String street;
	String bulding;
	String city;
	String state;
	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Address(Customer customer, int addressId, String area, String pin, String street, String bulding,
			String city, String state) {
		super();
		this.customer = customer;
		this.addressId = addressId;
		this.area = area;
		this.pin = pin;
		this.street = street;
		this.bulding = bulding;
		this.city = city;
		this.state = state;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public int getAddressId() {
		return addressId;
	}
	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getPin() {
		return pin;
	}
	public void setPin(String pin) {
		this.pin = pin;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getBulding() {
		return bulding;
	}
	public void setBulding(String bulding) {
		this.bulding = bulding;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	
}
