package com.mphasis.GroceryStore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.GroceryStore.entities.Delivery;
import com.mphasis.GroceryStore.entities.DeliveryDetails;
import com.mphasis.GroceryStore.service.DeliveryService;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/delivery")
public class DeliveryController {

	@Autowired
	DeliveryService deliveryService;
	@PostMapping("/add")
	public Delivery addDeliveryDetails(@RequestBody DeliveryDetails deliveryDetails) {
		return deliveryService.addDelivery(deliveryDetails);
	}
	
}
