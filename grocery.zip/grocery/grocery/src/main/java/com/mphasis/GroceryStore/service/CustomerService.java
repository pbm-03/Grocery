package com.mphasis.GroceryStore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.GroceryStore.Iservice.ICustomerService;
import com.mphasis.GroceryStore.Repository.ICustomerRepository;
import com.mphasis.GroceryStore.entities.Customer;

@Service
public class CustomerService implements ICustomerService{

	@Autowired
	ICustomerRepository customerRepository;
	@Override
	public Customer login(String email, String password) {
		// TODO Auto-generated method stub
		return customerRepository.findByEmailAndPassword(email, password);
	}

	@Override
	public Customer register(Customer customer) {
		// TODO Auto-generated method stub
		return customerRepository.save(customer);
	}

	@Override
	public Customer updateDetails(Customer customer) {
		// TODO Auto-generated method stub
		if(customerRepository.existsById(customer.getCustomerId()))
		{
			customerRepository.save(customer);
			return customer;
		}
		return null;
	}

	@Override
	public Customer getCustomerDetailsByEmail(String email) {
	    // Find the customer by email
	    Customer customer = customerRepository.findByEmail(email);
	    if (customer != null) {
	        return customerRepository.findById(customer.getCustomerId()).get();  // Assuming you are fetching the full customer data
	    } else {
	        return null; // or throw an exception if customer not found
	    }
	}
	@Override
	public List<Customer> getallDetails() {
		
		return customerRepository.findAll();
	}
 
	@Override
	public void deleteCustomerAccount(int customerId) {
		customerRepository.deleteById(customerId);
	}


}
