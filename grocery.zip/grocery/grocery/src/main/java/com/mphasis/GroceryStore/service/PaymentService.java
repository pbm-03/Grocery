package com.mphasis.GroceryStore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.GroceryStore.Iservice.IPaymentService;
import com.mphasis.GroceryStore.Repository.IAdminConfigRepository;
import com.mphasis.GroceryStore.Repository.ICartRepository;
import com.mphasis.GroceryStore.Repository.IPaymentRepository;
import com.mphasis.GroceryStore.entities.Order;
import com.mphasis.GroceryStore.entities.Payment;

@Service
public class PaymentService implements IPaymentService{

	
	@Autowired
	IPaymentRepository paymentRepository;
	@Autowired
	ICartRepository cartRepository;
	@Autowired
	IAdminConfigRepository adminConfigRepository;
	
	 @Override
	    public boolean makePayment(Order order, String paymentMethod) {
	        boolean flag = false;
	        Payment tempPayment = new Payment();
	        tempPayment.setOrder(order);
	        tempPayment.setPaymentMethod(paymentMethod);

	        // Set payment status based on the method (COD or online)
	        if(paymentMethod.equalsIgnoreCase("COD")) {
	            tempPayment.setPaymentStatus("Pending");
	        } else {
	            tempPayment.setPaymentStatus("Completed");
	        }

	        // Calculate the total price including taxes and delivery fee
	        double cartAmount = cartRepository.findByCustomerId(order.getCustomer().getCustomerId()).getTotalPrice();
	        double taxAmount = adminConfigRepository.findByPaymentMethod(paymentMethod).getTaxes() / 100;
	        double deliveryAmount = adminConfigRepository.findByPaymentMethod(paymentMethod).getDeliveryFee();

	        // Set the amount
	        tempPayment.setAmount((taxAmount * cartAmount) + cartAmount + deliveryAmount);

	        // Save payment information
	        paymentRepository.save(tempPayment);

	        if(tempPayment != null) {
	            flag = true;
	        }

	        return flag;
	    }

}
