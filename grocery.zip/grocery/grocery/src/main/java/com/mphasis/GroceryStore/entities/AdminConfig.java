package com.mphasis.GroceryStore.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
 
@Entity
public class AdminConfig {
 
	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	int adminConfigId;
	double deliveryFee;
	double taxes;
	String paymentMethods;
	public AdminConfig() {
		super();
		// TODO Auto-generated constructor stub
	}
	public AdminConfig(int adminConfigId, double deliveryFee, double taxes, String paymentMethods) {
		super();
		this.adminConfigId = adminConfigId;
		this.deliveryFee = deliveryFee;
		this.taxes = taxes;
		this.paymentMethods = paymentMethods;
	}
	public int getAdminConfigId() {
		return adminConfigId;
	}
	public void setAdminConfigId(int adminConfigId) {
		this.adminConfigId = adminConfigId;
	}
	public double getDeliveryFee() {
		return deliveryFee;
	}
	public void setDeliveryFee(double deliveryFee) {
		this.deliveryFee = deliveryFee;
	}
	public double getTaxes() {
		return taxes;
	}
	public void setTaxes(double taxes) {
		this.taxes = taxes;
	}
	public String getPaymentMethods() {
		return paymentMethods;
	}
	public void setPaymentMethods(String paymentMethods) {
		this.paymentMethods = paymentMethods;
	}
	@Override
	public String toString() {
		return "AdminConfig [adminConfigId=" + adminConfigId + ", deliveryFee=" + deliveryFee + ", taxes=" + taxes
				+ ", paymentMethods=" + paymentMethods + "]";
	}
	
}