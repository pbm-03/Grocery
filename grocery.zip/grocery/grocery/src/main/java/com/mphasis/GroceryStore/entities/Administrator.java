package com.mphasis.GroceryStore.entities;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
 
@Entity
public class Administrator {
	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	int administratorId;
	String name;
	String email;
	String contact;
	String password;
	
	@OneToMany(mappedBy = "administrator",cascade = CascadeType.ALL)
	@JsonIgnore
	List<Support>listOfSupport;
	public Administrator() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Administrator(int administratorId, String name, String email, String contact,
			List<Support> listOfSupport) {
		super();
		this.administratorId = administratorId;
		this.name = name;
		this.email = email;
		this.contact = contact;
		this.listOfSupport = listOfSupport;
	}
	public int getAdministratorId() {
		return administratorId;
	}
	public void setAdministratorId(int administratorId) {
		this.administratorId = administratorId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	
	public List<Support> getListOfSupport() {
		return listOfSupport;
	}
	public void setListOfSupport(List<Support> listOfSupport) {
		this.listOfSupport = listOfSupport;
	}
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}