package com.mphasis.GroceryStore.entities;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
 
@Entity
public class Customer {
	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int customerId;
	String customerName;
	String mobileNumber;
	String email;
	String password;
	@OneToMany(mappedBy = "customer",cascade = CascadeType.ALL)
	@JsonIgnore
	List<Address> address;
	@OneToMany(mappedBy = "customer",cascade = CascadeType.ALL)
	@JsonIgnore
	List<Order> listOfOrder;
	@OneToMany(mappedBy = "customer",fetch = FetchType.LAZY)
	@JsonIgnore
	List<Support>listOfSupport;
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer(int customerId, String customerName, String mobileNumber, String email, String password,
			List<Address> address, List<Order> listOfOrder, List<Support> listOfSupport) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.mobileNumber = mobileNumber;
		this.email = email;
		this.password = password;
		this.address = address;
		this.listOfOrder = listOfOrder;
		this.listOfSupport = listOfSupport;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public List<Address> getAddress() {
		return address;
	}
	public void setAddress(List<Address> address) {
		this.address = address;
	}
	
	public List<Order> getListOfOrder() {
		return listOfOrder;
	}
	public void setListOfOrder(List<Order> listOfOrder) {
		this.listOfOrder = listOfOrder;
	}
	public List<Support> getListOfSupport() {
		return listOfSupport;
	}
	public void setListOfSupport(List<Support> listOfSupport) {
		this.listOfSupport = listOfSupport;
	}
	
	
}
