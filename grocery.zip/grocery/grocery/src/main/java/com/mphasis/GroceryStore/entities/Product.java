package com.mphasis.GroceryStore.entities;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
 
@Entity
public class Product {
	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	int productId;
	String productName;
	String description;
	double price;
	int stockQnt;
	@ManyToOne(cascade = CascadeType.MERGE,fetch = FetchType.EAGER)
	@JoinColumn(name = "category_id")
	private Category category;
	String imgUrl;
//	@ManyToOne
//	@JoinColumn(name = "order_id")
//	Order order;
//	@ManyToOne
//	@JoinColumn(name = "cart_id")
//	Cart cart;
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getStockQnt() {
		return stockQnt;
	}
	public void setStockQnt(int stockQnt) {
		this.stockQnt = stockQnt;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	public String getImgUrl() {
		return imgUrl;
	}
	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}

}