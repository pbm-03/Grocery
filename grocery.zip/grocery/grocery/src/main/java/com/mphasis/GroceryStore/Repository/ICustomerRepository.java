package com.mphasis.GroceryStore.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.mphasis.GroceryStore.entities.Admin;
import com.mphasis.GroceryStore.entities.Customer;

@Repository
public interface ICustomerRepository extends JpaRepository<Customer, Integer> {

		@Query("SELECT a FROM Customer a WHERE a.email = :email AND a.password = :password")
	    Customer findByEmailAndPassword(@Param("email") String email, @Param("password") String password);
		@Query("select c from Customer c where c.email = :email")
		Customer findByEmail(@Param("email") String email);

	
}
