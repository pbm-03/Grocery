package com.mphasis.GroceryStore.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.mphasis.GroceryStore.entities.Product;

@Repository
public interface IProductRepository extends JpaRepository<Product, Integer> {
	
	@Query("select p from Product p where p.category.categoryName=:p1")
	public List<Product> findByCategoryName(@Param("p1")String categoryName);
	@Query("select p from Product p where p.price>=:p1 and p.price<=:p2")
	public List<Product> findByPrice(@Param("p1")double price1,@Param("p2")double price2);
	@Query("select p from Product p where p.productName=:p1")
	public List<Product> findByProductName(@Param("p1")String productName);
	
	
}
