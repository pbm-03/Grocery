package com.mphasis.GroceryStore.service;
 
import java.time.LocalDate;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
 
import com.mphasis.GroceryStore.Iservice.IOrderServices;
import com.mphasis.GroceryStore.Repository.ICartRepository;
import com.mphasis.GroceryStore.Repository.ICustomerRepository;
import com.mphasis.GroceryStore.Repository.IOrderRepository;
import com.mphasis.GroceryStore.entities.Cart;
import com.mphasis.GroceryStore.entities.Order;
 
@Service
public class OrderService implements IOrderServices{
 
	
	@Autowired
	IOrderRepository orderRepository;
	@Autowired
	ICartRepository cartRepository;
	@Autowired
	ICustomerRepository customerRepository;
	@Override
	public Order placeOrder(Order order,int customerId) {
		Cart tempCart=cartRepository.findByCustomerId(customerId);
		Order tempOrder=new Order();
		tempOrder.setCustomer(customerRepository.findById(customerId).get());
		tempOrder.setDelivery(null);
		tempOrder.setDeliveryAddress(null);
		tempOrder.setListOfProducts(cartRepository.findByCustomerId(customerId).getListOfProduct());
		tempOrder.setOrderDate(LocalDate.now());
		tempOrder.setOrderStatus("Placed");
		tempOrder.setPayment(null);
		orderRepository.save(tempOrder);
		return tempOrder;
	}
 
	@Override
	public boolean removeOrder(int customerId) {
		// TODO Auto-generated method stub
		orderRepository.deleteOrderByCustomerId(customerId);
		return true;
	}
 
}