package com.mphasis.GroceryStore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.GroceryStore.entities.Order;
import com.mphasis.GroceryStore.service.PaymentService;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/payment")
public class PaymentController {

	@Autowired
	PaymentService paymentService;
	@PostMapping("/addpayment/{p1}")
	public boolean makePayment(@RequestBody Order order,@PathVariable("p1") String paymentMethod) {
		return paymentService.makePayment(order, paymentMethod);
	}
	
}
