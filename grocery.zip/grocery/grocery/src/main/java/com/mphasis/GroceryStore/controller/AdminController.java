package com.mphasis.GroceryStore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.GroceryStore.entities.Admin;
import com.mphasis.GroceryStore.entities.AdminConfig;
import com.mphasis.GroceryStore.service.AdminConfigService;
import com.mphasis.GroceryStore.service.AdminService;

@CrossOrigin(origins = "http://localhost:4200")
//@CrossOrigin("*")
@RestController
@RequestMapping("/admin")
public class AdminController {
    @Autowired
    private AdminService adminService;
    @Autowired
    AdminConfigService adminConfigService;
 
    @GetMapping("/login/{p1}/{p2}")
    public Admin login(@PathVariable("p1")String email,@PathVariable("p2")String password) {
        Admin loggedInAdmin = adminService.login(email,password);
            return loggedInAdmin;
    }
    @PostMapping("/register")
    public Admin register(@RequestBody Admin admin) {
    	Admin registerAdmin=adminService.register(admin);
    	return registerAdmin;
    }
    @GetMapping("/getadmin/{p1}")
    public Admin getAdminDetail(@PathVariable("p1")String email) {
    	return adminService.getAdminByEmail(email);
    }
    
    @PostMapping("/addconfig")
    public AdminConfig addAdminConfig(@RequestBody AdminConfig adminConfig) {
    	return adminConfigService.addAdminConfig(adminConfig);
    }
    @DeleteMapping("/deleteconfig/{p1}")
    public boolean deleteAdminConfig(@PathVariable("p1") int adminConfigId) {
    	return adminConfigService.deleteAdminConfig(adminConfigId);
    }
    @PutMapping("/editconfig")
    public AdminConfig modifyAdminConfig(@RequestBody AdminConfig adminConfig) {
    	return adminConfigService.modifyAdminConfig(adminConfig);
    }
    @GetMapping("/viewadminconfig/{p1}")
    public AdminConfig viewAdminConfigByPaymentMethod(@PathVariable("p1")String paymentMethod) {
    	return adminConfigService.viewAdminConfigByPaymentMethod(paymentMethod);
    }
    @GetMapping("viewallconfig")
    public List<AdminConfig>viewAllConfig(){
    	return adminConfigService.getAllAdminConfig();
    }
    
}