package com.mphasis.GroceryStore.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.mphasis.GroceryStore.entities.Admin;
import com.mphasis.GroceryStore.entities.Administrator;

@Repository
public interface IAdministratorRepository extends JpaRepository<Administrator, Integer> {
	
	@Query("SELECT a FROM Administrator a WHERE a.email = :email AND a.password = :password")
    Administrator findByEmailAndPassword(@Param("email") String email, @Param("password") String password);
	@Query("select a from Administrator a where a.email=:email")
	Administrator findByEmail(@Param("email")String email);
}
