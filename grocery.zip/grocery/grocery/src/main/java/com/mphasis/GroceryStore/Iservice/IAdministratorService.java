package com.mphasis.GroceryStore.Iservice;

import com.mphasis.GroceryStore.entities.Administrator;

public interface IAdministratorService{

	public Administrator register(Administrator administrator);
	public Administrator login(String email, String password);
	public Administrator getAdminiDataByEmail(String email);
}


