package com.mphasis.GroceryStore.entities;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
 
@Entity
public class Cart {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int cartId;
	@OneToOne
	@JoinColumn(name = "customer_id")
	Customer customer;
	@OneToMany(fetch = FetchType.EAGER)
	List<Product>listOfProduct;
	double totalPrice;
	int qnt;
	public Cart() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Cart(int cartId, Customer customer, List<Product> listOfProduct, double totalPrice, int qnt) {
		super();
		this.cartId = cartId;
		this.customer = customer;
		this.listOfProduct = listOfProduct;
		this.totalPrice = totalPrice;
		this.qnt = qnt;
	}
	public int getCartId() {
		return cartId;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public List<Product> getListOfProduct() {
		return listOfProduct;
	}
	public void setListOfProduct(List<Product> listOfProduct) {
		this.listOfProduct = listOfProduct;
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public int getQnt() {
		return qnt;
	}
	public void setQnt(int qnt) {
		this.qnt = qnt;
	}
	
	
	
	
	@Override
	public String toString() {
		return "Cart [cartId=" + cartId + ", customer=" + customer + ", listOfProduct=" + listOfProduct
				+ ", totalPrice=" + totalPrice + ", qnt=" + qnt + "]";
	}
}