package com.mphasis.GroceryStore.Iservice;

import com.mphasis.GroceryStore.entities.Order;

public interface IPaymentService {
	public boolean makePayment(Order order,String paymentMethod);
}
