package com.mphasis.GroceryStore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mphasis.GroceryStore.Iservice.IAdminConfigService;
import com.mphasis.GroceryStore.Repository.IAdminConfigRepository;
import com.mphasis.GroceryStore.entities.AdminConfig;

@Service
public class AdminConfigService implements IAdminConfigService{
	
	
	
	@Autowired
	IAdminConfigRepository adminConfigRepository;

	@Override
	public AdminConfig addAdminConfig(AdminConfig adminConfig) {
		// TODO Auto-generated method stub
		adminConfigRepository.save(adminConfig);
		return adminConfig;
	}

	@Override
	public boolean deleteAdminConfig(int adminConfigId) {
		// TODO Auto-generated method stub
		adminConfigRepository.deleteById(adminConfigId);
		return true;
	}

	@Override
	public AdminConfig modifyAdminConfig(AdminConfig adminConfig) {
		// TODO Auto-generated method stub
		if(adminConfigRepository.existsById(adminConfig.getAdminConfigId())) {
			adminConfigRepository.save(adminConfig);
			return adminConfig;
		}
		return null;
	}

	@Override
	public AdminConfig viewAdminConfigByPaymentMethod(String paymentMethod) {
		// TODO Auto-generated method stub
		return adminConfigRepository.findByPaymentMethod(paymentMethod);
	}

	@Override
	public List<AdminConfig> getAllAdminConfig() {
		// TODO Auto-generated method stub
		return adminConfigRepository.findAll();
	}

	
}
