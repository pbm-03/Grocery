package com.mphasis.GroceryStore.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
 
@Entity
public class Delivery {
	@Id
	//@GeneratedValue(strategy = GenerationType.AUTO)
	int deliveryId;
	@OneToOne
	@JoinColumn(name = "order_id")
	Order order;
	@ManyToOne
	@JoinColumn(name ="deliveryperson_id" )
	DeliveryPerson deliveryperson;
	String deliveryStatus;
	String deliveryOption;
	public Delivery() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Delivery(int deliveryId, Order order, DeliveryPerson deliveryperson, String deliveryStatus,
			String deliveryOption) {
		super();
		this.deliveryId = deliveryId;
		this.order = order;
		this.deliveryperson = deliveryperson;
		this.deliveryStatus = deliveryStatus;
		this.deliveryOption = deliveryOption;
	}
	public int getDeliveryId() {
		return deliveryId;
	}
	public void setDeliveryId(int deliveryId) {
		this.deliveryId = deliveryId;
	}
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
	public DeliveryPerson getDeliveryperson() {
		return deliveryperson;
	}
	public void setDeliveryperson(DeliveryPerson deliveryperson) {
		this.deliveryperson = deliveryperson;
	}
	public String getDeliveryStatus() {
		return deliveryStatus;
	}
	public void setDeliveryStatus(String deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}
	public String getDeliveryOption() {
		return deliveryOption;
	}
	public void setDeliveryOption(String deliveryOption) {
		this.deliveryOption = deliveryOption;
	}
	@Override
	public String toString() {
		return "Delivery [deliveryId=" + deliveryId + ", order=" + order + ", deliveryperson=" + deliveryperson
				+ ", deliveryStatus=" + deliveryStatus + ", deliveryOption=" + deliveryOption + "]";
	}
	
}