package com.mphasis.GroceryStore.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mphasis.GroceryStore.entities.Delivery;

public interface IDeliveryRepository extends JpaRepository<Delivery, Integer> {

}
