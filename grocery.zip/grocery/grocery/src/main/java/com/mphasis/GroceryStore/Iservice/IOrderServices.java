package com.mphasis.GroceryStore.Iservice;
 
import com.mphasis.GroceryStore.entities.Order;
 
public interface IOrderServices {
	public Order placeOrder(Order order,int customerId);
	public boolean removeOrder(int customerId);
}