package com.mphasis.GroceryStore.Iservice;

import java.util.List;

import com.mphasis.GroceryStore.entities.Category;
import com.mphasis.GroceryStore.entities.CategoryDetails;
import com.mphasis.GroceryStore.entities.Product;

public interface IProductService {
	public List<Product> viewProducts();
	public List<Product> searchByCatagories(String catagoryName);
	public List<Product> searchByPrice(double price1,double price2);
	public List<Product> searchByKeyword(String productName);
	
	public Category addNewCategory(CategoryDetails categoryDetails);
	public List<Category> viewAllCategory();
	public Product addProduct(Product product);
	public Product updateProduct(Product product);
	public Product removeProduct(int productId);
	public Product getProductById(int productId);

}
