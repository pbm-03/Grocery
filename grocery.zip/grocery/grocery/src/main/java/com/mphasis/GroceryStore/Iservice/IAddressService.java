package com.mphasis.GroceryStore.Iservice;

import java.util.List;

import com.mphasis.GroceryStore.entities.Address;
import com.mphasis.GroceryStore.entities.AddressDetails;

public interface IAddressService {
	public Address UpdateAddress(AddressDetails addressDetails,int customerId);
	public Address addAddress(AddressDetails addressDetails,int customerId);
	public boolean deleteAddress(Address address);
}
