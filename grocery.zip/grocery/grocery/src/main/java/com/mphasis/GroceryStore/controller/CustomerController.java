package com.mphasis.GroceryStore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.GroceryStore.entities.Address;
import com.mphasis.GroceryStore.entities.AddressDetails;
import com.mphasis.GroceryStore.entities.Admin;
import com.mphasis.GroceryStore.entities.Customer;
import com.mphasis.GroceryStore.service.AddressService;
import com.mphasis.GroceryStore.service.CustomerService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/customer")
public class CustomerController {
	
	@Autowired
	CustomerService customerService;
	@Autowired
	AddressService addressService;
	
	@GetMapping("/login/{p1}/{p2}")
	public Customer login(@PathVariable("p1")String email,@PathVariable("p2")String password) {
		Customer customerLoggin=customerService.login(email, password);
		return customerLoggin;
	}
	@PostMapping("/register")
	public Customer register(@RequestBody Customer customer) {
		return customerService.register(customer);
	}
	@GetMapping("/customerdetails/{p1}")
	public Customer getCustomerByCustomerEmail(@PathVariable("p1") String customerEmail) {
	    return customerService.getCustomerDetailsByEmail(customerEmail);
	}
	@GetMapping("getAllCustomerDetails")
	public List<Customer> getallCustomer(){
		return customerService.getallDetails();
	}
	
	@DeleteMapping("deleteByCustomerID/{p1}")
	public void deleteaccount(@PathVariable("p1") int customerId) {
		customerService.deleteCustomerAccount(customerId);
		
	}
	
	@PutMapping("updateDetails")
	public Customer updateCustomerDetails(@RequestBody Customer customer) {
		return customerService.updateDetails(customer);
	}
	
	@PutMapping("/updateaddress/{p1}")
	public Address UpdateAddress(@RequestBody AddressDetails addressDetails,@PathVariable("p1")int customerId) {
		return addressService.UpdateAddress(addressDetails, customerId);
	}
	
	@PostMapping("/addaddress/{p1}")
	public Address addAddress(AddressDetails addressDetails,int customerId) {
		return addressService.addAddress(addressDetails, customerId);
	}
	@DeleteMapping("/deleteaddress")
	public boolean deleteAddress(@RequestBody Address address) {
		return addressService.deleteAddress(address);
	}
	
}
