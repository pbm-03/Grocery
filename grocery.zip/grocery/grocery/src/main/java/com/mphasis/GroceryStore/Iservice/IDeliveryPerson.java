package com.mphasis.GroceryStore.Iservice;

import java.util.List;

import com.mphasis.GroceryStore.entities.Delivery;

public interface IDeliveryPerson {

}
