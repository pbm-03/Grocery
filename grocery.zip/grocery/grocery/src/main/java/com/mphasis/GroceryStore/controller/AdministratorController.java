package com.mphasis.GroceryStore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.GroceryStore.entities.Administrator;
import com.mphasis.GroceryStore.entities.Customer;
import com.mphasis.GroceryStore.service.AdministratorService;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/administrator")
public class AdministratorController {
	
	@Autowired
	AdministratorService administratorService;
	@GetMapping("/login/{p1}/{p2}")
    public Administrator login(@PathVariable("p1")String email,@PathVariable("p2")String password) {
        Administrator loggedInAdministrator =administratorService.login(email, password);
            return loggedInAdministrator;
    }
    @PostMapping("/register")
    public Administrator register(@RequestBody Administrator administrator) {
    	Administrator registerAdministrator=administratorService.register(administrator);
    	return registerAdministrator;
    }
    @GetMapping("/getadmini/{p1}")
    public Administrator getAdmini(@PathVariable("p1")String email) {
    	return administratorService.getAdminiDataByEmail(email);
    }
}
