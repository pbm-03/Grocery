package com.mphasis.GroceryStore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.GroceryStore.Iservice.IAdministratorService;
import com.mphasis.GroceryStore.Repository.IAdministratorRepository;
import com.mphasis.GroceryStore.entities.Administrator;

@Service
public class AdministratorService implements IAdministratorService{
	@Autowired
	IAdministratorRepository administratorRepository;
	
 
	@Override
	public Administrator login(String email, String password) {
		// TODO Auto-generated method stub
		return administratorRepository.findByEmailAndPassword(email, password);
	}
 
	@Override
	public Administrator register(Administrator administrator) {
		// TODO Auto-generated method stub
		return administratorRepository.save(administrator);
	}

	@Override
	public Administrator getAdminiDataByEmail(String email) {
		// TODO Auto-generated method stub
		return administratorRepository.findByEmail(email);
	}

}
