package com.mphasis.GroceryStore.Iservice;

import com.mphasis.GroceryStore.entities.Delivery;
import com.mphasis.GroceryStore.entities.DeliveryDetails;
import com.mphasis.GroceryStore.entities.Order;

public interface IDeliveryService {
	public Delivery addDelivery(DeliveryDetails deliveryDetails);
}
