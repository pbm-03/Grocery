package com.mphasis.GroceryStore.controller;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
 
import com.mphasis.GroceryStore.entities.Order;
import com.mphasis.GroceryStore.service.OrderService;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/order")
public class OrderController {
 
	@Autowired
	OrderService orderService;
	@PostMapping("/placeorder/{p1}")
	public Order placeOrder(@PathVariable("p1") int customerId,@RequestBody Order order)
	{
		return orderService.placeOrder(order, customerId);
	}
	@DeleteMapping("/removeorder/{p1}")
	public boolean removeOrder(@PathVariable("p1")int cutomerId) {
		return orderService.removeOrder(cutomerId);
	}
}