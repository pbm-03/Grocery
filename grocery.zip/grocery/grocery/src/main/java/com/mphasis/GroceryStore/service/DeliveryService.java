package com.mphasis.GroceryStore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.GroceryStore.Iservice.IDeliveryService;
import com.mphasis.GroceryStore.Repository.IDeliveryPersonRepository;
import com.mphasis.GroceryStore.Repository.IDeliveryRepository;
import com.mphasis.GroceryStore.entities.Delivery;
import com.mphasis.GroceryStore.entities.DeliveryDetails;
import com.mphasis.GroceryStore.entities.Order;

@Service
public class DeliveryService implements IDeliveryService{

	
	@Autowired
	IDeliveryRepository deliveryRepository;
	@Autowired
	IDeliveryPersonRepository deliveryPersonRepository;
	
	@Override
    public Delivery addDelivery(DeliveryDetails deliveryDetails) {
        Delivery delivery = new Delivery();
        delivery.setDeliveryOption(deliveryDetails.getDeliveryOption());
        delivery.setDeliveryperson(deliveryPersonRepository.findById(deliveryDetails.getDeliveryPersonId()).get());
        delivery.setDeliveryStatus("Pending"); // Status can be set as 'Pending' initially
        delivery.setOrder(deliveryDetails.getOrder());

        deliveryRepository.save(delivery);
        return delivery;
    }
	
}
