package com.mphasis.GroceryStore.Iservice;

import java.util.List;

import com.mphasis.GroceryStore.entities.Customer;

public interface ICustomerService {
	 
	public Customer login(String email,String password);
	public Customer register(Customer customer);
	public Customer updateDetails(Customer customer);
	public Customer getCustomerDetailsByEmail(String email);
	public List<Customer> getallDetails();
	public void deleteCustomerAccount(int customerId);
}
