package com.mphasis.GroceryStore.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.GroceryStore.Iservice.ICartService;
import com.mphasis.GroceryStore.Repository.ICartRepository;
import com.mphasis.GroceryStore.Repository.ICustomerRepository;
import com.mphasis.GroceryStore.Repository.IProductRepository;
import com.mphasis.GroceryStore.entities.Cart;
import com.mphasis.GroceryStore.entities.Customer;
import com.mphasis.GroceryStore.entities.Product;

import jakarta.transaction.Transactional;

@Service
public class CartService implements ICartService {

    @Autowired
    ICartRepository cartRepo;
    
    @Autowired
    ICustomerRepository customerRepository;
    
    @Autowired
    IProductRepository productRepository;

    @Override
    public Cart viewCart(String email) {
        Customer customer = customerRepository.findByEmail(email);
        if (customer == null) {
            throw new RuntimeException("Customer not found");
        }
        Cart cart = cartRepo.findByCustomerId(customer.getCustomerId());
        if (cart == null) {
            throw new RuntimeException("Cart not found for this customer");
        }
        return cart;
    }

    @Override
    @Transactional
    public Cart addToCart(Product product, String email) {
        Customer customer = customerRepository.findByEmail(email);
        if (customer == null) {
            throw new RuntimeException("Customer not found");
        }

        // Find the cart for the customer, or create a new one if it doesn't exist
        Cart cart = cartRepo.findByCustomerId(customer.getCustomerId());
        if (cart == null) {
            cart = new Cart();
            cart.setCustomer(customer);
            cart.setListOfProduct(new ArrayList<>());
            cart.setQnt(0);
            cart.setTotalPrice(0.0);
        }

        // Check if the product is already in the cart
        Product existingProduct = null;
        for (Product p : cart.getListOfProduct()) {
            if (p.getProductId() == product.getProductId()) {
                existingProduct = p;
                break;
            }
        }

        if (existingProduct != null) {
            // If product exists, increase the quantity of the product in the cart
            cart.getListOfProduct().remove(existingProduct); // Remove old instance
            existingProduct.setStockQnt(existingProduct.getStockQnt() + 1); // Increment quantity
            cart.getListOfProduct().add(existingProduct); // Add updated product
        } else {
            // Otherwise, add the new product with quantity 1
            product.setStockQnt(1); // Assuming stock quantity for the cart is 1
            cart.getListOfProduct().add(product);
        }

        // Recalculate the total price
        double tempPrice = 0;
        for (Product p : cart.getListOfProduct()) {
            tempPrice += p.getPrice();
        }
        cart.setTotalPrice(tempPrice);

        // Recalculate the quantity
        cart.setQnt(cart.getListOfProduct().size());

        // Save the updated cart
        cartRepo.save(cart);

        return cart;
    }


    @Override
    @Transactional
    public Cart removeCart(int productid, int customerId) {
        // Find the cart for the customer
        Cart cart = cartRepo.findByCustomerId(customerId);
        if (cart == null) {
            throw new RuntimeException("Cart not found for this customer");
        }

        // Find the product to remove
        Product productToRemove = productRepository.findById(productid).get();
        if (productToRemove == null) {
            throw new RuntimeException("Product not found");
        }

        // Remove the product from the cart
        boolean removed = cart.getListOfProduct().remove(productToRemove);
        if (!removed) {
            throw new RuntimeException("Product not found in cart");
        }

        double tempPrice = 0;
        for (Product p : cart.getListOfProduct()) {
            tempPrice += p.getPrice();
        }
        cart.setTotalPrice(tempPrice);

        // Recalculate the quantity
        cart.setQnt(cart.getListOfProduct().size());

        // Save the updated cart
        cartRepo.save(cart);

        return cart;
    }
}
