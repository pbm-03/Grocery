package com.mphasis.GroceryStore.entities;

import java.util.List;

public class OrderRequest {

	        private int customerId;
	        private List<Product> listOfProducts;
	        private Address deliveryAddress;
	        private String paymentMethod;

	        public int getCustomerId() {
	            return customerId;
	        }

	        public void setCustomerId(int customerId) {
	            this.customerId = customerId;
	        }

	        public List<Product> getListOfProducts() {
	            return listOfProducts;
	        }

	        public void setListOfProducts(List<Product> listOfProducts) {
	            this.listOfProducts = listOfProducts;
	        }

	        public Address getDeliveryAddress() {
	            return deliveryAddress;
	        }

	        public void setDeliveryAddress(Address deliveryAddress) {
	            this.deliveryAddress = deliveryAddress;
	        }

	        public String getPaymentMethod() {
	            return paymentMethod;
	        }

	        public void setPaymentMethod(String paymentMethod) {
	            this.paymentMethod = paymentMethod;
	        }
	    }

