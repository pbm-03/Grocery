package com.mphasis.GroceryStore.entities;

import java.time.LocalDate;
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "order_tbl")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int orderId;

    @ManyToOne
    @JoinColumn(name = "customer_id")
    private Customer customer;

    @OneToMany(fetch = FetchType.LAZY)
    private List<Product> listOfProducts;

    @OneToOne
    @JoinColumn(name = "address_id")
    private Address deliveryAddress;

    private LocalDate orderDate;

    private String orderStatus;

    @OneToOne
    @JoinColumn(name = "payment_id")
    private Payment payment;

    @OneToOne
    @JoinColumn(name = "delivery_id")
    private Delivery delivery;

    // Getters and Setters

    public Order() {
    }

    public Order(int orderId, Customer customer, List<Product> listOfProducts, Address deliveryAddress,
                 LocalDate orderDate, String orderStatus, Payment payment, Delivery delivery) {
        this.orderId = orderId;
        this.customer = customer;
        this.listOfProducts = listOfProducts;
        this.deliveryAddress = deliveryAddress;
        this.orderDate = orderDate;
        this.orderStatus = orderStatus;
        this.payment = payment;
        this.delivery = delivery;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public List<Product> getListOfProducts() {
        return listOfProducts;
    }

    public void setListOfProducts(List<Product> listOfProducts) {
        this.listOfProducts = listOfProducts;
    }

    public Address getDeliveryAddress() {
        return deliveryAddress;
    }

    public void setDeliveryAddress(Address deliveryAddress) {
        this.deliveryAddress = deliveryAddress;
    }

    public LocalDate getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(LocalDate orderDate) {
        this.orderDate = orderDate;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public Payment getPayment() {
        return payment;
    }

    public void setPayment(Payment payment) {
        this.payment = payment;
    }

    public Delivery getDelivery() {
        return delivery;
    }

    public void setDelivery(Delivery delivery) {
        this.delivery = delivery;
    }

    @Override
    public String toString() {
        return "Order{" +
                "orderId=" + orderId +
                ", customer=" + customer +
                ", listOfProducts=" + listOfProducts +
                ", deliveryAddress=" + deliveryAddress +
                ", orderDate=" + orderDate +
                ", orderStatus='" + orderStatus + '\'' +
                ", payment=" + payment +
                ", delivery=" + delivery +
                '}';
    }
}
