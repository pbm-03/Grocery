package com.mphasis.GroceryStore.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.mphasis.GroceryStore.entities.Order;
import com.mphasis.GroceryStore.entities.Product;

@Repository
public interface IOrderRepository extends JpaRepository<Order, Integer> {
	
	@Modifying
	@Query("delete from Order o where o.customer.customerId=:p1")
	public boolean deleteOrderByCustomerId(@Param("p1")int customerId);
	
}
