package com.mphasis.GroceryStore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.GroceryStore.Iservice.IAdminService;
import com.mphasis.GroceryStore.Repository.IAdminRepository;
import com.mphasis.GroceryStore.entities.Admin;

@Service
public class AdminService implements IAdminService{
 
    @Autowired
    private IAdminRepository adminRepository;
 
    @Override
    public Admin login(String email, String password) {
        return adminRepository.findByEmailAndPassword(email, password);
    }
 
    @Override
    public Admin register(Admin admin) {
        return adminRepository.save(admin);
    }

	@Override
	public Admin getAdminByEmail(String email) {
		// TODO Auto-generated method stub
		return adminRepository.findByEmail(email);
	}
}