package com.mphasis.GroceryStore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.GroceryStore.Iservice.IProductService;
import com.mphasis.GroceryStore.Repository.ICategoryRepository;
import com.mphasis.GroceryStore.Repository.IProductRepository;
import com.mphasis.GroceryStore.entities.Category;
import com.mphasis.GroceryStore.entities.CategoryDetails;
import com.mphasis.GroceryStore.entities.Product;

@Service
public class ProductService implements IProductService{
	
	
	
	@Autowired
	IProductRepository productRepository;
	@Autowired
	ICategoryRepository categoryRepository;

	@Override
	public List<Product> viewProducts() {
		// TODO Auto-generated method stub
		return productRepository.findAll();
	}

	@Override
	public List<Product> searchByCatagories(String catagoryName) {
		// TODO Auto-generated method stub
		return productRepository.findByCategoryName(catagoryName);
	}

	@Override
	public List<Product> searchByPrice(double price1,double price2) {
		// TODO Auto-generated method stub
		return productRepository.findByPrice(price1, price2);
	}

	@Override
	public List<Product> searchByKeyword(String productName) {
		// TODO Auto-generated method stub
		return productRepository.findByProductName(productName);
	}

	@Override
	public Product addProduct(Product product) {
		// TODO Auto-generated method stub
		return productRepository.save(product);
	}

	@Override
	public Product updateProduct(Product product) {
		// TODO Auto-generated method stub
		if(productRepository.existsById(product.getProductId())) {
			productRepository.save(product);
			return product;
		}
		return null;
	}

	@Override
	public Product removeProduct(int productId) {
		// TODO Auto-generated method stub
		if(productRepository.existsById(productId)) {
			Product product=productRepository.findById(productId).get();
			productRepository.deleteById(productId);
			return product;
		}
		return null;
	}

	@Override
	public Category addNewCategory(CategoryDetails categoryDetails) {
		// TODO Auto-generated method stub
		Category tempCatagory=new Category();
		tempCatagory.setCategoryId(categoryDetails.getCategoryId());
		tempCatagory.setCategoryName(categoryDetails.getCategoryName());
		categoryRepository.save(tempCatagory);
		return tempCatagory;
	}

	@Override
	public List<Category> viewAllCategory() {
		// TODO Auto-generated method stub
		return categoryRepository.findAll();
	}

	@Override
	public Product getProductById(int productId) {
		// TODO Auto-generated method stub
		return productRepository.findById(productId).get();
	}


}
