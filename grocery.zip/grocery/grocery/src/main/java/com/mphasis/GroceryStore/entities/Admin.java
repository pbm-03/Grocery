package com.mphasis.GroceryStore.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
 
@Entity
public class Admin {
	@Id
	//@GeneratedValue(strategy = GenerationType.AUTO)
	int adminId;
	String adminName;
	String email;
	String adminContact;
	String password;
	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Admin(int adminId, String adminName, String adminEmail, String adminContact) {
		super();
		this.adminId = adminId;
		this.adminName = adminName;
		this.email = adminEmail;
		this.adminContact = adminContact;
		
	}
	
	public int getAdminId() {
		return adminId;
	}
	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}
	public String getAdminName() {
		return adminName;
	}
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	public String getAdminEmail() {
		return email;
	}
	public void setAdminEmail(String email) {
		this.email = email;
	}
	public String getAdminContact() {
		return adminContact;
	}
	public void setAdminContact(String adminContact) {
		this.adminContact = adminContact;
	}
	
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
