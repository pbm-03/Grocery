package com.mphasis.GroceryStore.Iservice;

import java.util.List;

import com.mphasis.GroceryStore.entities.Support;
import com.mphasis.GroceryStore.entities.SupportRequest;

public interface ISupportService {
	public Support addSupport(SupportRequest supportRequest);
	public List<Support> findByCustomerId(int customerId);
	public List<Support> findByAdministratorId(int adminstratorId);
}
