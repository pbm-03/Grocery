package com.mphasis.GroceryStore.entities;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
 
@Entity
public class Category {
	@Id
	//@GeneratedValue(strategy = GenerationType.AUTO)
	int categoryId;
	String categoryName;
	@OneToMany(mappedBy = "category")
	@JsonIgnore
	List<Product> listOfProduct;
	public Category() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Category(int categoryId, String categoryName, List<Product> listOfProduct) {
		super();
		this.categoryId = categoryId;
		this.categoryName = categoryName;
		this.listOfProduct = listOfProduct;
	}
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public List<Product> getListOfProduct() {
		return listOfProduct;
	}
	public void setListOfProduct(List<Product> listOfProduct) {
		this.listOfProduct = listOfProduct;
	}
	@Override
	public String toString() {
		return "Category [categoryId=" + categoryId + ", categoryName=" + categoryName + ", listOfProduct="
				+ listOfProduct + "]";
	}
	
}
