package com.mphasis.GroceryStore.Iservice;

import com.mphasis.GroceryStore.entities.Cart;
import com.mphasis.GroceryStore.entities.Product;

public interface ICartService {
	public Cart viewCart(String email);
	public Cart addToCart(Product product,String email);
	public Cart removeCart(int productId,int cutomerId);
}
