package com.mphasis.GroceryStore.entities;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
 
@Entity
public class DeliveryPerson {
 
	@Id
	int deliveryPersonId;
	String name;
	@OneToMany(mappedBy = "deliveryperson",cascade = CascadeType.ALL)
	List<Delivery>listOfDelivery;
	public DeliveryPerson() {
		super();
		// TODO Auto-generated constructor stub
	}
	public DeliveryPerson(int deliveryPersonId, String name, List<Delivery> listOfDelivery) {
		super();
		this.deliveryPersonId = deliveryPersonId;
		this.name = name;
		this.listOfDelivery = listOfDelivery;
	}
	public int getDeliveryPersonId() {
		return deliveryPersonId;
	}
	public void setDeliveryPersonId(int deliveryPersonId) {
		this.deliveryPersonId = deliveryPersonId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Delivery> getListOfDelivery() {
		return listOfDelivery;
	}
	public void setListOfDelivery(List<Delivery> listOfDelivery) {
		this.listOfDelivery = listOfDelivery;
	}
	@Override
	public String toString() {
		return "DeliveryPerson [deliveryPersonId=" + deliveryPersonId + ", name=" + name + ", listOfDelivery="
				+ listOfDelivery + "]";
	}
	
}